import json
import cv2
import os

all_classes = {'焊缝焊渣': 0, '擦伤漏铁': 1, '异常盖子': 2, '凹陷': 3, '杂质油污': 4}
savepath = "E:/RBData/COCOLabels20230906/"
jsonpath = "E:/RBData/JSON/"
imgpath = "E:/RBData/ALL20230905/"
json_files = os.listdir(jsonpath)

for i in json_files:
    infile = jsonpath + i
    with open(infile, 'r', encoding='utf-8-sig') as load_f:
        load_dict = json.load(load_f)

    # Check if the 'shapes' key exists in the loaded dictionary
    if 'shapes' not in load_dict:
        print(f"'shapes' key not found in {infile}")
        continue

    img_path = imgpath + load_dict["imagePath"]

    # Check if the image file exists
    if not os.path.exists(img_path):
        print(f"Image file not found: {img_path}")
        continue

    img = cv2.imread(img_path)

    # Check if the image was successfully loaded
    if img is None:
        print(f"Failed to load image: {img_path}")
        continue

    size = img.shape
    h_img, w_img = size[0], size[1]

    outfile = open(savepath + load_dict["imagePath"][:-4] + '.txt', 'w')

    for item in load_dict["shapes"]:
        label_int = all_classes[item['label']]
        if not item['points']:
            continue
        x1, y1 = item['points'][0]
        x2, y2 = item['points'][1]
        x_center = (x1 + x2) / 2 / w_img
        y_center = (y1 + y2) / 2 / h_img
        w = (x2 - x1) / w_img
        h = (y2 - y1) / h_img
        outfile.write(str(label_int) + " " + str(x_center) + " " + str(y_center) + " " + str(w) + " " + str(h) + '\n')

    outfile.close()
